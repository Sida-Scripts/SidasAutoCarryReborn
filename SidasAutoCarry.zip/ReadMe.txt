=== Install Instructions ===

1. Extract the "Scripts" and "Sprites" folders to your BoL folder.
2. Reload BoL
3. Click the "Custom Scripts" tab and enable "Sidas Auto Carry.lua"
4. Start a custom game.

=== More Information ===

For more information about the script please visit the forum thread at http://forum.botoflegends.com/topic/6584-