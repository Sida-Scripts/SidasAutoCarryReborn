For more information about the script please visit the forum thread at http://forum.botoflegends.com/topic/6584-

=== Install Instructions ===

1. Extract the "Scripts" and "Sprites" folders to your BoL folder.
2. Reload BoL
3. Click the "Custom Scripts" tab and enable "Sidas Auto Carry.lua"
4. Start a custom game.

=== Manually downloading files ===

This zip contains all of the required script files, but prediction files are still needed.
The script will automatically download them, but if for some reason you experience issues with auto-download,
you can install the files manually from the following locations:

VPrediction: 
    https://raw.githubusercontent.com/SidaBoL/Scripts/master/Common/VPrediction.lua
    Save as "VPrediction.lua"

Fun House Prediction: 
    http://www.funhouse.me/fhprediction/FHPrediction.lua
    Save as "FHPrediction.lua"

HPrediction:
    https://raw.githubusercontent.com/BolHTTF/BoL/master/HTTF/Common/HPrediction.lua
    Save as "HPrediction.lua"

KPrediction:
    https://raw.githubusercontent.com/BolHTTF/BoL/master/HTTF/Common/KPrediction.lua
    Save as "KPrediction.lua"

These files should be saved into your BoL/Scripts/Common folder.